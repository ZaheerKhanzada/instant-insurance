import React from 'react';
import blogBg from '../../assets/blog.jpg';
import { Navbar } from '../../Components/Navbar/Navbar';
import { FooterTwo } from '../../Components/Footer/FooterTwo';
import './Blogs.css';
import { Link } from 'react-router-dom';

export const Blogs = () => {
	return (
		<>
			<Navbar />
			<div className="blogs">
				<div className="bHeading">
					<h1>Blogs</h1>
					<h3>Read our latest Blogs</h3>
				</div>

				<div className="blogs-list">
					<div className="singleBlog">
						<div className="blogImage">
							<img src={blogBg} alt='blog' />
						</div>
						<div className="blogDesc">
							<Link className='blogLink'><h2>Blog Title</h2></Link>
							<p>Blog Summary. Lorem ipsum dolor sit amet consectetur adipisicing elit. Officia dignissimos fuga exercitationem neque unde facilis minima corporis accusamus ea voluptatibus.
							</p>
						</div>
					</div>

					<div className="singleBlog">
						<div className="blogImage">
							<img src={blogBg} alt='blog' />
						</div>
						<div className="blogDesc">
							<Link className='blogLink'><h2>Blog Title</h2></Link>
							<p>Blog Summary. Lorem ipsum dolor sit amet consectetur adipisicing elit. Officia dignissimos fuga exercitationem neque unde facilis minima corporis accusamus ea voluptatibus.
							</p>
						</div>
					</div>

					<div className="singleBlog">
						<div className="blogImage">
							<img src={blogBg} alt='blog' />
						</div>
						<div className="blogDesc">
							<Link className='blogLink'><h2>Blog Title</h2></Link>
							<p>Blog Summary. Lorem ipsum dolor sit amet consectetur adipisicing elit. Officia dignissimos fuga exercitationem neque unde facilis minima corporis accusamus ea voluptatibus.
							</p>
						</div>
					</div>

					<div className="singleBlog">
						<div className="blogImage">
							<img src={blogBg} alt='blog' />
						</div>
						<div className="blogDesc">
							<Link className='blogLink'><h2>Blog Title</h2></Link>
							<p>Blog Summary. Lorem ipsum dolor sit amet consectetur adipisicing elit. Officia dignissimos fuga exercitationem neque unde facilis minima corporis accusamus ea voluptatibus.
							</p>
						</div>
					</div>
				</div>
			</div>

			<FooterTwo />
		</>
	)
}
