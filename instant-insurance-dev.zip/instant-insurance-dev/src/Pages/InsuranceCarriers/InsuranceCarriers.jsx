import React, { useEffect, useRef, useState } from 'react'
import { Navbar } from '../../Components/Navbar/Navbar';
import { InsuranceHero } from '../../Components/InsuranceTypes/InsuranceHero/InsuranceHero';
import { WhyChooseUs } from '../../Components/WhyChooseUs/WhyChooseUs';
import { FooterTwo } from '../../Components/Footer/FooterTwo';
import { motion, useAnimation, useInView } from 'framer-motion';
import hiscox from '../../assets/logos/hiscox.png';
import cna from '../../assets/logos/cna.png';
import liberty from '../../assets/logos/liberty.png';
import next from '../../assets/logos/next.png';
import hartford from '../../assets/logos/hartford.png';
import chubb from '../../assets/chubb.png';
import encompass from '../../assets/logos/encompass.png';
import safeco from '../../assets/logos/safeco.png';
import plymoth from '../../assets/logos/plymouth.svg';
import travelers from '../../assets/logos/travelers.png';
import './InsuranceCarriers.css';

const initialVaariants = {
  hidden: {
    x: -100,
    opacity: 0
  },
  visible: {
    transform: 'skew(27deg)',
    x: 0,
    opacity: 1,
  }
}

const descVaariants = {
  hidden: {
    opacity: 0
  },
  visible: {
    opacity: 1,
  }
}

export const InsuranceCarriers = () => {

  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });
  const mainControls = useAnimation();

  useEffect(() => {
    if (isInView) {
      mainControls.start("visible");
    }
  }, [isInView, mainControls])

  useEffect(() => {
    document.title = 'Insurance Carriers -Instantly Insured';
  }, []);

  const [selectedCategory, setSelectedCategory] = useState('Commercial'); // Initialize with the default category

  const handleCategoryChange = (category) => {
    setSelectedCategory(category);
  };

  // Define your insurance carriers data based on categories
  const insuranceCarriersData = {
    Commercial: [
      {
        name: 'CNA',
        description: "CNA is a well-established insurance carrier that specializes in providing a wide range of commercial insurance solutions. With a focus on businesses, CNA offers coverage for property, liability, and more. Their deep industry expertise, risk management resources, and dedication to understanding each client's unique needs make CNA a reliable partner for businesses seeking comprehensive protection.",
        logo: cna,
      },
      {
        name: 'Liberty Mutual',
        description: "Liberty Mutual is a global insurance carrier known for its diverse range of coverage options, including auto, home, and life insurance. With a strong commitment to customer service and innovative offerings, Liberty Mutual aims to provide policyholders with the confidence to embrace life's adventures. Their financial stability and wide-reaching network make them a trusted choice for individuals and families.",
        logo: liberty,
      },
      {
        name: 'Hiscox',
        description: "Hiscox is a specialized insurance carrier catering to the unique needs of businesses, professionals, and individuals. With a focus on specialty lines such as professional liability and cyber insurance, Hiscox provides tailored solutions to mitigate risks specific to various industries. Their emphasis on expertise and responsive claims handling sets them apart as a reliable partner for specialized coverage.",
        logo: hiscox,
      },
      {
        name: 'NEXT',
        description: 'NEXT Insurance is a tech-driven insurance carrier that aims to revolutionize the insurance industry. Focusing on small businesses, NEXT offers straightforward and customizable coverage solutions designed to meet the evolving needs of modern entrepreneurs. Their digital platform, user-friendly experience, and commitment to innovation make NEXT Insurance a fresh and promising option for small business owners.',
        logo: next,
      },
      {
        name: 'The Hartford',
        description: "The Hartford is a well-established insurance carrier with a strong presence in both personal and commercial insurance. With a rich history dating back over 200 years, The Hartford offers a range of coverage options, from auto and home to workers' compensation and group benefits. Their dedication to customer service and focus on long-term relationships make them a reliable and respected choice in the insurance industry.",
        logo: hartford,
      },
      // Add more auto insurance carriers here
    ],
    Personal: [
      {
        name: 'Chubb',
        description: 'Chubb is a renowned insurance carrier known for its exceptional coverage options and commitment to delivering peace of mind to policyholders. With a legacy spanning over a century, Chubb offers a wide range of insurance solutions, including property, casualty, and specialty lines. Their reputation for financial stability and superior customer service makes them a trusted choice for individuals and businesses seeking comprehensive insurance coverage.',
        logo: chubb,
      },
      {
        name: 'Encompass',
        description: "Encompass is a leading insurance carrier that focuses on providing tailored personal insurance solutions to protect your most valuable assets. Their offerings include coverage for homes, autos, and valuable possessions. With a customer-centric approach and a range of customizable options, Encompass aims to deliver personalized protection that aligns with each policyholder's unique needs.",
        logo: encompass,
      },
      {
        name: 'Safeco Insurance',
        description: "Safeco Insurance is committed to making insurance simple and accessible. As part of the Liberty Mutual Group, Safeco offers a diverse range of insurance products, from auto and home to umbrella and more. With a user-friendly approach and a reputation for fast and efficient claims processing, Safeco aims to provide policyholders with the security and confidence they need to face life's uncertainties.",
        logo: safeco,
      },
      {
        name: 'Travelers',
        description: "Travelers is a leading insurance carrier known for its innovative solutions and broad range of coverage options. With a focus on both personal and commercial insurance, Travelers provides protection against risks ranging from property damage to liability. Their strong financial standing and commitment to customer service make them a reliable choice for individuals and businesses seeking comprehensive insurance coverage.",
        logo: travelers,
      },
      {
        name: 'Plymouth Rock',
        description: "Plymouth Rock Assurance stands out for its customer-centric approach and commitment to simplifying insurance. Offering a range of auto and home insurance options, Plymouth Rock aims to provide policyholders with peace of mind and convenience. Their emphasis on technology and personalized service ensures that policyholders receive the support they need, backed by a trusted carrier.",
        logo: plymoth,
      },
    ],
  };

  const selectedCarriers = insuranceCarriersData[selectedCategory];

  return (
    <>
      <Navbar />
      <InsuranceHero currentPage="Insurance Carriers" />

      <div className="icContent">
        <div className="iccDesc">
          <h2 ref={ref}>Explore the insurance carriers we collaborate with</h2>
        </div>

        {/* Category Selection Buttons */}
        <div className="category-buttons">
          <button
            className={selectedCategory === 'Commercial' ? 'selected' : ''}
            onClick={() => handleCategoryChange('Commercial')}
          >
            Commercial
          </button>
          <button
            className={selectedCategory === 'Personal' ? 'selected' : ''}
            onClick={() => handleCategoryChange('Personal')}
          >
            Personal
          </button>

        </div>

        {selectedCarriers.map((carrier, index) => (
          <div className="section">
            <div className="carrier">
              <div className="heading">
                <motion.h3
                  variants={initialVaariants}
                  initial="hidden"
                  animate={mainControls}
                  transition={{ delay: 0.3, duration: 1 }}
                >{carrier.name}</motion.h3>
              </div>
            </div>
            <div className="content">
              <motion.p
                variants={descVaariants}
                initial="hidden"
                animate={mainControls}
                transition={{ delay: 0.8, duration: 1.5 }}
              >{carrier.description}</motion.p>
            </div>

          </div>

        ))}

        {selectedCategory === 'Commercial' && (
          <div className="carriersCLogos">
            <div className="carrierLogo">
              <img src={hiscox} alt="Hiscox" />
            </div>

            <div className="carrierLogo">
              <img src={cna} alt="CNA" />
            </div>

            <div className="carrierLogo">
              <img src={liberty} alt="Liberty" />
            </div>

            <div className="carrierLogo">
              <img src={next} alt="NEXT" />
            </div>

            <div className="carrierLogo">
              <img src={hartford} alt="Hartford" />
            </div>
          </div>
        )}

        {selectedCategory === 'Personal' && (
          <div className="carriersCLogos">
            <div className="carrierLogo">
              <img src={chubb} alt="Chubb" />
            </div>

            <div className="carrierLogo">
              <img src={encompass} alt="Encompass" />
            </div>

            <div className="carrierLogo">
              <img src={safeco} alt="SAFECO" />
            </div>

            <div className="carrierLogo">
              <img src={plymoth} alt="Plymoth" />
            </div>

            <div className="carrierLogo">
              <img src={travelers} alt="Travelers" />
            </div>
          </div>
        )}

      </div>

      <WhyChooseUs currentPage="InsuranceCarriers" />
      <FooterTwo />
    </>
  )
}
