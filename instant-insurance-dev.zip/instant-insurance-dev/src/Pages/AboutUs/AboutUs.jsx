import React, { useEffect } from 'react'
import { Navbar } from '../../Components/Navbar/Navbar'
// import { Footer } from '../../Components/Footer/Footer'
import { AboutHero } from '../../Components/AboutHero/AboutHero'
import { APContent } from '../../Components/AboutPageContent/APContent'
import { FooterTwo } from '../../Components/Footer/FooterTwo'

export const AboutUs = () => {

  useEffect(() => {
		document.title = 'About Us -Instantly Insured';
	  }, []);

  return (
    <div>
      <Navbar />
      <AboutHero />
      <APContent />
      <FooterTwo />
    </div>
  )
}
