import React from 'react';
import bg from '../../assets/bg.jpeg';
import './Hero.css';
import { Link } from 'react-router-dom';

export const Hero = () => {
  return (
    <div className='hero'>
      <img src={bg} alt="" className="heroImg" />
        <div className="heroDesc">
          <h1 className="heroTitle">Instantly Insured: Your Shield Against the Unexpected</h1>
          <h2 className="heroSubTitle">Protecting New York Families, Homes, and Businesses with Comprehensive Insurance Solutions</h2>
          <Link to="/get_a_quote"><button className='quote-btn heroBtn'>Get a Quote</button></ Link>
        </div>
    </div>
  )
}
