import React from 'react';
import googleLogo from '../../assets/logos/google.svg';
import zillowLogo from '../../assets/logos/zillow.svg';
import StarIcon from '@mui/icons-material/Star';
import { A11y, Autoplay } from 'swiper/modules';
import { Swiper, SwiperSlide } from 'swiper/react';
import './TestimonialV2.css';


const testimonials = [
  {
    quote: "Instantly Insured made getting home insurance a breeze! Their quick and easy process gave me peace of mind knowing my home is protected.",
    person: "Sarah Thompson",
  },
  {
    quote: "I'm impressed with Instantly Insured's personalized approach. They tailored a home insurance plan that fits my needs perfectly. Great service!",
    person: "John Smith",
  },
  {
    quote: "Kudos to Instantly Insured for their excellent customer support. They patiently answered all my questions, helping me choose the right home insurance coverage.",
    person: "Emily Rodriguez",
  },
  {
    quote: "Instantly Insured not only saved me money but also provided comprehensive coverage. I recommend them to anyone looking for hassle-free home insurance.",
    person: "Michael Johnson",
  },
  // Add more testimonials as needed
];

export const TestimonialV2 = () => {

  const swiperParams = {
    slidesPerView: 1, // Default slides per view (for larger screens)
    spaceBetween: 20,
    // navigation: true,
    speed: 1200,
    autoplay: {
      delay: 2000,
      disableOnInteraction: false,
    },
    breakpoints: {
      1024: {
        slidesPerView: 2,
      },
      1440: {
        slidesPerView: 3,
      },
    },
  };

  return (
    <>
      <div className="testimonial">
        <div className="testContent">
          <div className="googleImg">
            <img src={googleLogo} alt="google" />
            <div className="stars">
              <StarIcon className='starIcon' />
              <StarIcon className='starIcon' />
              <StarIcon className='starIcon' />
              <StarIcon className='starIcon' />
              <StarIcon className='starIcon' />
            </div>
            <h3>EXCELLENT</h3>
          </div>

          <div className="testimonials">
            <Swiper {...swiperParams} modules={[A11y, Autoplay]}>
              {testimonials.map((testimonial, index) => (
                <SwiperSlide key={index}>
                  <div className="testimonial-container">


                    <div className="people-quotes">
                      <div className="person-detail">
                        <h4>{testimonial.person}</h4>
                      </div>
                      <div className="stars">
                        <StarIcon className='starIcon quote' />
                        <StarIcon className='starIcon quote' />
                        <StarIcon className='starIcon quote' />
                        <StarIcon className='starIcon quote' />
                        <StarIcon className='starIcon quote' />
                      </div>
                      <div className="quote">
                        <p>{testimonial.quote}</p>
                      </div>
                    </div>
                  </div>
                </SwiperSlide>
              ))}
            </Swiper>
          </div>
        </div>

        <div className="testContent">
          <div className="googleImg">
            <img src={zillowLogo} alt="google" />
            <div className="stars">
              <StarIcon className='starIcon zillow' />
              <StarIcon className='starIcon zillow' />
              <StarIcon className='starIcon zillow' />
              <StarIcon className='starIcon zillow' />
              <StarIcon className='starIcon zillow' />
            </div>
            <h3>EXCELLENT</h3>
          </div>

          <div className="testimonials">
            <Swiper {...swiperParams} modules={[A11y, Autoplay]}>
              {testimonials.map((testimonial, index) => (
                <SwiperSlide key={index}>
                  <div className="testimonial-container">


                    <div className="people-quotes">
                      <div className="person-detail">
                        <h4>{testimonial.person}</h4>
                      </div>
                      <div className="stars">
                        <StarIcon className='starIcon zillow quote' />
                        <StarIcon className='starIcon zillow quote' />
                        <StarIcon className='starIcon zillow quote' />
                        <StarIcon className='starIcon zillow quote' />
                        <StarIcon className='starIcon zillow quote' />
                      </div>
                      <div className="quote">
                        <p>{testimonial.quote}</p>
                      </div>
                    </div>
                  </div>
                </SwiperSlide>
              ))}
            </Swiper>
          </div>
        </div>
      </div>
    </>
  )
}
