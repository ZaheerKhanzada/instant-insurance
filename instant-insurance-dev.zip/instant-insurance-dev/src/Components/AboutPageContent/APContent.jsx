import React from 'react';
import './APContent.css';

export const APContent = () => {
  return (
    <div className='apContentSec'>
      <div className="contentItem">
        <h2>Who We Are</h2>
        <p>We are a team of experienced insurance professionals with a collective mission – to provide New York residents with the highest level of insurance services. Our expertise spans a wide range of insurance domains, from auto and home to medical and business insurance, enabling us to offer comprehensive solutions to meet your unique needs.</p>
      </div>

      <div className="contentItem">
        <h2>Our Commitment</h2>
        <p>At Instantly Insured, we hold firm to our motto, "Expect the Unexpected." We understand that life can present unexpected challenges, and our commitment is to prepare you for those moments with tailored insurance plans. As a locally focused brokerage, we take the time to understand your individual circumstances, family dynamics, and business goals to recommend the most suitable coverage options.</p>
      </div>

      <div className="midHeading">
        <h2><span className='hlHeading'>Why Choose </span>Instantly Insured</h2>
      </div>

      <div className="contentItem">
        <h2>Personalized Service</h2>
        <p>We believe in building relationships, not just transactions. When you choose us, you gain a dedicated insurance advisor who will work closely with you, ensuring your policies align perfectly with your needs.</p>
      </div>

      <div className="contentItem">
        <h2>Local Expertise</h2>
        <p>With deep roots in New York, we have an in-depth understanding of the region's unique insurance requirements. Our knowledge of the local market enables us to navigate the complexities efficiently.</p>
      </div>

      <div className="contentItem">
        <h2>Trusted Partnerships</h2>
        <p>We have cultivated strong partnerships with reputable insurance carriers, allowing us to access a wide range of insurance products that meet our clients' diverse needs.</p>
      </div>

      <div className="contentItem">
        <h2>Transparent and Honest</h2>
        <p>Integrity is at the core of our values. We provide transparent information about policies, coverage, and premiums, ensuring you can make informed decisions.</p>
      </div>

      <div className="contentItem">
        <h2>Customer-Centric Approach</h2>
        <p>Your satisfaction is our top priority. We go the extra mile to ensure you feel heard, supported, and valued throughout your insurance journey.</p>
      </div>

      <div className="contentItem">
        <h2>Our Mission</h2>
        <p>Our mission at Instantly Insured is to empower New York residents and businesses with the right insurance solutions, fostering security and peace of mind. We strive to make the insurance process seamless, stress-free, and rewarding, ensuring that you receive the protection you deserve without any compromise.</p>
      </div>

      <div className="contentItem">
        <h2>Community Involvement</h2>
        <p>We believe in giving back to the community that has embraced us so warmly. Through various initiatives, sponsorships, and volunteer work, we actively contribute to the betterment of New York and its residents.</p>
      </div>

      <div className="apInvite">
        <p>Join us at Instantly Insured, and experience the difference a dedicated insurance partner can make. Together, we'll navigate the unpredictable future, safeguarding your dreams and aspirations with the right insurance coverage. Expect the Unexpected, and rest assured, we've got you covered.</p>
        <button className='quote-btn abtBtn'>Get a Quote</button>
      </div>
    </div>
  )
}
