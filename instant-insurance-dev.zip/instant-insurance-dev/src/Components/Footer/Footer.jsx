import React from 'react';
import { Link } from 'react-router-dom';
import FacebookIcon from '@mui/icons-material/Facebook';
import TwitterIcon from '@mui/icons-material/Twitter';
import InstagramIcon from '@mui/icons-material/Instagram';
import './Footer.css';

export const Footer = () => {
  return (
    <div className='footer'>
      <div className="navLink">
        <div className="links">
          <Link className='fLink' to="/">Home</Link>
          <Link className='fLink' to="/about_us">About Us</Link>
          <Link className='fLink' to="/insurance_services">Insurance Services</Link>
          <Link className='fLink' to="/insurance_carriers">Insurance Carriers</Link>
          <Link className='fLink' to="/contact_us">Contact Us</Link>
        </div>
        <div className="socialMedia">
          <FacebookIcon className='fsIcon'/>
          <TwitterIcon className='fsIcon'/>
          <InstagramIcon className='fsIcon'/>
        </div>
      </div>

      <div className="footerContent">
        <div className="fContentDesc">
          <h3>Instant Insurance</h3>
          <h4>At Instantly Insured, we believe in transparent communication and addressing your concerns. If you have any other questions or need further information, please don't hesitate to reach out to our team. Expect the Unexpected, and trust in our commitment to your insurance needs.</h4>
        </div>
        <div className="fContact">
          <h3>Contact</h3>
          {/* <div className="fCAddress"> */}
            <h4>4 NEW HYDE PARK RD, FRANKLIN SQUARE, NY 11010, United States</h4>
          {/* </div> */}
        </div>
      </div>

      <div className="copyWrite">
        <div className="copyRightText">
          <p>&#169; 2023 Instant Insurance. All Rights Reserved</p>
        </div>
        <div className="policyLinks">
          <Link><p>Terms of Service</p></Link>
          <Link><p>Privacy Policy</p></Link>
        </div>
      </div>
    </div>
  )
}
