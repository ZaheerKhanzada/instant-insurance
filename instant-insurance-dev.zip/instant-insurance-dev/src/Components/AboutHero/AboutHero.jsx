import React from 'react';
import aboutBg from '../../assets/5.jpg';
import './AboutHero.css';

export const AboutHero = () => {
  return (
    <div className='aboutHero'>
      <div className="aboutUsHero">
        <img src={aboutBg} alt="" className="abtHeroImg" />
        <div className="aHeroDesc">
          <div className="aHDContent">
            <h1>ABOUT US</h1>
            <h4>At Instantly Insured, we take immense pride in being a trusted and prominent <spn className="hlText">insurance brokerage firm</spn> serving the New York community. With a passion for protecting what matters most to our clients, we have established ourselves as a reliable partner in navigating the complex world of insurance.</h4>
          </div>
        </div>
      </div>
    </div>
  )
}
